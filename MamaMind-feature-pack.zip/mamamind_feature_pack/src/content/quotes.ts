export type Mood = 'tired' | 'anxious' | 'happy' | 'overwhelmed' | 'lonely' | 'proud';

export const quotes: Record<Mood, string[]> = {
  tired: [
    'Rest is productive too.', 'You do not have to earn a pause.', 'Tiny steps count on tired days.',
    'Today can be gentle and still be enough.', 'A slower pace is still a pace forward.',
    'You are allowed to recharge before the next thing.', 'Your body has done a lot. Be kind to it.',
  ],
  anxious: [
    'One breath is enough to begin again.', 'You can take this moment one small piece at a time.',
    'You do not need every answer right now.', 'Let today be softer than your worries.',
    'Pause, breathe, and return to what is in front of you.', 'You are not alone in the messy middle.',
    'A worried mind deserves tenderness too.',
  ],
  happy: [
    'Let this little bright moment stay with you.', 'Joy can be tiny and still be real.',
    'Save this feeling somewhere in your heart.', 'You are making beautiful ordinary memories.',
    'Your smile belongs in this story too.', 'Celebrate the small wins—they are everywhere.',
    'There is room for you inside the happy moments.',
  ],
  overwhelmed: [
    'You only need to do the next kind thing.', 'You are enough, exactly as you are today.',
    'Not everything needs to be solved today.', 'Put one thing down and breathe.',
    'Asking for help is a form of care.', 'A messy day is not a failed day.',
    'You can make the day smaller when it feels too big.',
  ],
  lonely: [
    'You deserve to feel held, too.', 'Someone else has had a day like this.',
    'You can reach for one safe person today.', 'Being tired of carrying everything is human.',
    'You matter outside every role you are carrying.', 'Connection can start with one honest sentence.',
    'You do not have to make loneliness look pretty.',
  ],
  proud: [
    'Look how much you have already learned.', 'You kept going through moments you once feared.',
    'You are building your own rhythm.', 'Every tiny act of care is part of your story.',
    'You can be proud without needing to be perfect.', 'Your effort counts even when nobody sees it.',
    'There is a strong, soft person growing here—you.',
  ],
};

export function quoteForMood(mood: Mood): string {
  const list = quotes[mood];
  return list[Math.floor(Math.random() * list.length)];
}

export const dailyQuotes = [
  'You and your baby are learning each other, one ordinary moment at a time.',
  'There is no perfect version of today. There is only this moment, and you are here.',
  'Care for yourself in the same gentle voice you use for your little one.',
  'Your needs are part of the family story, not an interruption to it.',
  'You are allowed to be proud of surviving the days that felt long.',
  'Small care creates a softer home.',
];
