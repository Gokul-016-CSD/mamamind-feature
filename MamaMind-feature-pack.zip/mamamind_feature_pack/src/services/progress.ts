import AsyncStorage from '@react-native-async-storage/async-storage';

export type Milestone = {
  id: string;
  title: string;
  unlocked: boolean;
  action: string;
};

export const MILESTONES: Omit<Milestone, 'unlocked'>[] = [
  { id: 'cuddle', title: 'First Cuddle', action: 'mood' },
  { id: 'night', title: 'Survived the Night Feeds', action: 'breathe' },
  { id: 'help', title: 'Asked for Help', action: 'journal' },
  { id: 'moment', title: 'Took a Moment for Me', action: 'selfcare' },
  { id: 'smile', title: 'First Smile', action: 'water' },
  { id: 'rhythm', title: 'Found My Rhythm', action: 'rest' },
  { id: 'me', title: 'Feeling Like Me Again', action: 'journal' },
];

const key = (userId: string) => `mamamind-progress-${userId}`;

export async function getProgress(userId: string): Promise<Milestone[]> {
  const raw = await AsyncStorage.getItem(key(userId));
  if (!raw) return MILESTONES.map((m, i) => ({ ...m, unlocked: i === 0 }));
  return JSON.parse(raw);
}

export async function unlockNext(userId: string): Promise<Milestone[]> {
  const current = await getProgress(userId);
  const index = current.findIndex((m) => !m.unlocked);
  if (index >= 0) current[index].unlocked = true;
  await AsyncStorage.setItem(key(userId), JSON.stringify(current));
  return current;
}
