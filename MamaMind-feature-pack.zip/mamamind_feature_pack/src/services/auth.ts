import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from './supabase';

export type User = { id: string; email: string; name: string; babyName: string; babyAge: string };
const SESSION = 'mamamind-session';

export async function getUser(): Promise<User | null> {
  if (supabase) {
    const { data } = await supabase.auth.getUser();
    if (data.user) {
      const local = await AsyncStorage.getItem(`${SESSION}-${data.user.id}`);
      const profile = local ? JSON.parse(local) : {};
      return { id: data.user.id, email: data.user.email ?? '', name: profile.name ?? 'Mama', babyName: profile.babyName ?? 'Little One', babyAge: profile.babyAge ?? 'Newborn' };
    }
    return null;
  }
  const raw = await AsyncStorage.getItem(SESSION);
  return raw ? JSON.parse(raw) : null;
}

export async function signIn(email: string, password: string): Promise<User> {
  if (supabase) {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error || !data.user) throw new Error(error?.message ?? 'Could not sign in.');
    const user = await getUser();
    if (!user) throw new Error('Signed in, but the profile could not be loaded.');
    return user;
  }
  const existing = await getUser();
  const user = existing ?? { id: `demo-${email.toLowerCase()}`, email, name: 'Mama', babyName: 'Little One', babyAge: 'Newborn' };
  await AsyncStorage.setItem(SESSION, JSON.stringify(user));
  return user;
}

export async function signUp(email: string, password: string, name = 'Mama'): Promise<User> {
  if (supabase) {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error || !data.user) throw new Error(error?.message ?? 'Could not create your account.');
    const user: User = { id: data.user.id, email: data.user.email ?? email, name, babyName: 'Little One', babyAge: 'Newborn' };
    await AsyncStorage.setItem(`${SESSION}-${user.id}`, JSON.stringify(user));
    return user;
  }
  const user: User = { id: `demo-${Date.now()}`, email, name, babyName: 'Little One', babyAge: 'Newborn' };
  await AsyncStorage.setItem(SESSION, JSON.stringify(user));
  return user;
}

export async function updateUser(patch: Partial<User>): Promise<User | null> {
  const current = await getUser(); if (!current) return null;
  const next = { ...current, ...patch };
  if (supabase) await AsyncStorage.setItem(`${SESSION}-${current.id}`, JSON.stringify(next));
  else await AsyncStorage.setItem(SESSION, JSON.stringify(next));
  return next;
}

export async function signOut() {
  if (supabase) await supabase.auth.signOut();
  await AsyncStorage.removeItem(SESSION);
}
