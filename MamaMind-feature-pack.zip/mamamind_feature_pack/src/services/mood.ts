import type { Mood } from '@/content/quotes';

export type MoodResult = {
  mood: Mood;
  message: string;
  suggestion: string;
  needsSupport: boolean;
};

export function interpretMood(mood: Mood): MoodResult {
  const map: Record<Mood, Omit<MoodResult, 'mood'>> = {
    tired: { message: 'You sound like someone who has been giving a lot.', suggestion: 'Take 60 seconds for water and one slow breath.', needsSupport: false },
    anxious: { message: 'It makes sense that your mind wants a little reassurance.', suggestion: 'Try the Breathe & Relax space for one minute.', needsSupport: false },
    happy: { message: 'I am glad there is a little brightness here today.', suggestion: 'Save this moment in your Happy Jar.', needsSupport: false },
    overwhelmed: { message: 'You do not have to carry the whole day at once.', suggestion: 'Pick just one tiny thing to pause or hand to someone else.', needsSupport: false },
    lonely: { message: 'You deserve company and care, too.', suggestion: 'Send one honest message to someone safe.', needsSupport: false },
    proud: { message: 'That feeling is worth noticing.', suggestion: 'Write down one thing you handled today.', needsSupport: false },
  };
  return { mood, ...map[mood] };
}
