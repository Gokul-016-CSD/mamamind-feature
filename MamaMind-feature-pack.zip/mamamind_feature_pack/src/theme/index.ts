import { Platform } from 'react-native';
import { colors } from './colors';

export const spacing = {
  xs: 6, sm: 10, md: 16, lg: 22, xl: 30, xxl: 40,
};
export const radius = {
  sm: 12, md: 20, lg: 28, pill: 999,
};
export const typography = {
  display: 30,
  h1: 25,
  h2: 20,
  body: 16,
  small: 13,
  button: 16,
};
export const shadows = {
  soft: Platform.select({
    ios: { shadowColor: '#4A3F55', shadowOpacity: 0.08, shadowRadius: 18, shadowOffset: { width: 0, height: 8 } },
    android: { elevation: 3 },
    default: {},
  }),
};
export { colors };
