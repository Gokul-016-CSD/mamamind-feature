export const colors = {
  sunrisePeach: '#FFB59E',
  butterYellow: '#FFE08A',
  mintBreeze: '#A8E6CF',
  skyLullaby: '#A5D8FF',
  lavenderHug: '#D8C6F5',
  background: '#FFF9F2',
  text: '#4A3F55',
  muted: '#756A80',
  white: '#FFFFFF',
  softBorder: '#E9DFE8',
  success: '#4F806B',
  info: '#4E7190',
} as const;

export type PaletteName = keyof typeof colors;

export const gradients = {
  sunrise: [colors.sunrisePeach, colors.butterYellow],
  calm: [colors.mintBreeze, colors.skyLullaby],
  dreamy: [colors.lavenderHug, colors.skyLullaby],
  joy: [colors.butterYellow, colors.sunrisePeach],
} as const;
