import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Path } from 'react-native-svg';
import { colors, radius, spacing } from '@/theme';
import { getProgress, unlockNext, type Milestone } from '@/services/progress';
import { getUser } from '@/services/auth';

export function JourneyGame() {
  const [items, setItems] = useState<Milestone[]>([]);
  const load = async () => { const user = await getUser(); if (user) setItems(await getProgress(user.id)); };
  useEffect(() => { load(); }, []);
  const celebrate = async () => { const user = await getUser(); if (!user) return; setItems(await unlockNext(user.id)); };
  return <View style={styles.card}>
    <Text style={styles.title}>How far have you come? 🌷</Text>
    <Text style={styles.sub}>There is no falling behind here. Every tiny act of care moves you forward.</Text>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.pathWrap}>
      <Svg width={items.length * 145} height={170}>
        <Path d={`M20 115 C100 15, 155 160, 230 75 S380 20, 450 100 S600 160, 710 65 S850 10, ${items.length * 145 - 30} 95`} fill="none" stroke={colors.lavenderHug} strokeWidth="18" strokeLinecap="round" />
        {items.map((m, i) => <Circle key={m.id} cx={45 + i * 145} cy={i % 2 ? 72 : 110} r="22" fill={m.unlocked ? colors.sunrisePeach : colors.white} stroke={colors.text} strokeWidth="2" opacity={m.unlocked ? 1 : .35} />)}
      </Svg>
      <View style={styles.labels}>{items.map((m, i) => <View key={m.id} style={[styles.stop, { left: i * 145 }]}><Text style={styles.mini}>{m.unlocked ? '♡' : '○'}</Text><Text style={styles.label}>{m.title}</Text></View>)}</View>
    </ScrollView>
    <Pressable onPress={celebrate} style={({ pressed }) => [styles.action, pressed && { transform: [{ scale: .97 }] }]}><Text style={styles.actionText}>Do one kind thing → unlock next</Text></Pressable>
  </View>;
}
const styles = StyleSheet.create({ card: { backgroundColor: colors.white, borderRadius: radius.lg, padding: spacing.lg, marginTop: spacing.lg }, title: { fontSize: 21, fontWeight: '900', color: colors.text }, sub: { color: colors.muted, lineHeight: 20, marginTop: 5 }, pathWrap: { paddingTop: 10, paddingBottom: 8 }, labels: { position: 'absolute', left: 0, top: 0, height: 170 }, stop: { position: 'absolute', width: 120, alignItems: 'center' }, mini: { fontSize: 18, color: colors.text }, label: { textAlign: 'center', fontSize: 11, fontWeight: '800', color: colors.text, marginTop: 55 }, action: { minHeight: 48, backgroundColor: colors.mintBreeze, borderRadius: radius.pill, alignItems: 'center', justifyContent: 'center' }, actionText: { color: colors.text, fontWeight: '900' } });
