import React from 'react';
import { Pressable, StyleProp, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { colors, radius, shadows, spacing, typography } from '@/theme';

export function Screen({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return <View style={[styles.screen, style]}>{children}</View>;
}
export function Card({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return <View style={[styles.card, style]}>{children}</View>;
}
export function PrimaryButton({ title, onPress, disabled = false }: { title: string; onPress: () => void; disabled?: boolean }) {
  return <Pressable accessibilityRole="button" disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.button, pressed && styles.pressed, disabled && styles.disabled]}><Text style={styles.buttonText}>{title}</Text></Pressable>;
}
export function SoftButton({ title, onPress }: { title: string; onPress: () => void }) {
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.softButton, pressed && styles.pressed]}><Text style={styles.softText}>{title}</Text></Pressable>;
}
export function SectionTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return <View style={{ marginBottom: spacing.md }}><Text style={styles.sectionTitle}>{title}</Text>{subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}</View>;
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background, padding: spacing.lg },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, padding: spacing.lg, ...shadows.soft },
  button: { minHeight: 52, paddingHorizontal: 22, borderRadius: radius.pill, backgroundColor: colors.sunrisePeach, alignItems: 'center', justifyContent: 'center' },
  buttonText: { color: colors.text, fontWeight: '800', fontSize: typography.button },
  softButton: { minHeight: 48, paddingHorizontal: 18, borderRadius: radius.pill, backgroundColor: colors.lavenderHug, alignItems: 'center', justifyContent: 'center' },
  softText: { color: colors.text, fontWeight: '800' },
  pressed: { transform: [{ scale: 0.97 }] },
  disabled: { opacity: 0.5 },
  sectionTitle: { color: colors.text, fontSize: typography.h2, fontWeight: '900' },
  subtitle: { color: colors.muted, fontSize: typography.small, lineHeight: 19, marginTop: 4 },
});
