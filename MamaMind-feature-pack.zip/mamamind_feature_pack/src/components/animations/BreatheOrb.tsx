import React, { useEffect, useRef, useState } from 'react';
import { Animated, Easing, StyleSheet, Text, View } from 'react-native';
import { colors } from '@/theme';

export function BreatheOrb({ running = true }: { running?: boolean }) {
  const scale = useRef(new Animated.Value(0.82)).current;
  const [phase, setPhase] = useState('Breathe in');
  useEffect(() => {
    if (!running) return;
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(scale, { toValue: 1.18, duration: 4500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(scale, { toValue: 0.82, duration: 5500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    const id = setInterval(() => setPhase(p => p === 'Breathe in' ? 'Breathe out' : 'Breathe in'), 5000);
    return () => { loop.stop(); clearInterval(id); };
  }, [running, scale]);
  return <View style={styles.center}><Animated.View style={[styles.orb, { transform: [{ scale }] }]}><Text style={styles.emoji}>♡</Text></Animated.View><Text style={styles.phase}>{phase}</Text><Text style={styles.sub}>Nothing to fix. Just breathe with me.</Text></View>;
}
const styles = StyleSheet.create({ center: { alignItems: 'center', justifyContent: 'center', paddingVertical: 30 }, orb: { width: 170, height: 170, borderRadius: 85, backgroundColor: colors.mintBreeze, alignItems: 'center', justifyContent: 'center', shadowColor: colors.skyLullaby, shadowOpacity: .35, shadowRadius: 30 }, emoji: { fontSize: 54, color: colors.text }, phase: { marginTop: 24, fontSize: 22, fontWeight: '900', color: colors.text }, sub: { marginTop: 8, color: colors.muted, textAlign: 'center' } });
