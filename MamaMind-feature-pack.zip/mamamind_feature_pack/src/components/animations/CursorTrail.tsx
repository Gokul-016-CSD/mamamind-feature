import React, { useEffect, useRef } from 'react';
import { Animated, Easing, Platform, StyleSheet, View } from 'react-native';
import { colors } from '@/theme';

export function CursorTrail({ enabled = true }: { enabled?: boolean }) {
  const opacity = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (Platform.OS !== 'web' || !enabled) return;
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(opacity, { toValue: 1, duration: 900, easing: Easing.out(Easing.quad), useNativeDriver: true }),
      Animated.timing(opacity, { toValue: 0, duration: 1500, easing: Easing.in(Easing.quad), useNativeDriver: true }),
    ]));
    loop.start(); return () => loop.stop();
  }, [enabled, opacity]);
  if (Platform.OS !== 'web' || !enabled) return null;
  return <Animated.View pointerEvents="none" style={[styles.trail, { opacity }]} />;
}
const styles = StyleSheet.create({ trail: { position: 'absolute', width: 80, height: 80, borderRadius: 40, backgroundColor: colors.lavenderHug, opacity: 0.18, right: 18, bottom: 120 } });
