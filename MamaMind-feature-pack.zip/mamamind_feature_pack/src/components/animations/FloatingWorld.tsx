import React, { useEffect, useRef } from 'react';
import { Animated, Easing, Platform, StyleSheet, useWindowDimensions, View } from 'react-native';
import Svg, { Circle, Path } from 'react-native-svg';
import { colors } from '@/theme';

const particles = [
  { x: 8, y: 14, s: 1.0, c: colors.sunrisePeach, kind: 'bubble' },
  { x: 82, y: 11, s: 0.8, c: colors.butterYellow, kind: 'star' },
  { x: 91, y: 30, s: 0.7, c: colors.mintBreeze, kind: 'bubble' },
  { x: 12, y: 48, s: 0.65, c: colors.skyLullaby, kind: 'bubble' },
  { x: 87, y: 62, s: 0.75, c: colors.lavenderHug, kind: 'heart' },
  { x: 18, y: 78, s: 0.7, c: colors.butterYellow, kind: 'star' },
];

export function FloatingWorld({ calm = false }: { calm?: boolean }) {
  const { width, height } = useWindowDimensions();
  const values = useRef(particles.map(() => new Animated.Value(0))).current;
  useEffect(() => {
    if (Platform.OS !== 'web' && calm) return;
    const animations = values.map((v, i) => Animated.loop(Animated.sequence([
      Animated.timing(v, { toValue: 1, duration: (calm ? 9000 : 5500) + i * 500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration: (calm ? 9000 : 5500) + i * 500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ])));
    animations.forEach(a => a.start());
    return () => animations.forEach(a => a.stop());
  }, [calm, values]);
  return <View pointerEvents="none" style={StyleSheet.absoluteFill}>
    {particles.map((p, i) => {
      const translateY = values[i].interpolate({ inputRange: [0, 1], outputRange: [0, -18 - i * 3] });
      const scale = values[i].interpolate({ inputRange: [0, .5, 1], outputRange: [1, 1.08, 1] });
      return <Animated.View key={i} style={[styles.particle, { left: width * p.x / 100, top: height * p.y / 100, transform: [{ translateY }, { scale }] }]}>
        <Svg width={28 * p.s} height={28 * p.s} viewBox="0 0 28 28">
          {p.kind === 'bubble' && <Circle cx="14" cy="14" r="8" fill={p.c} opacity={0.55} />}
          {p.kind === 'star' && <Path d="M14 2l2.8 7.4L25 12l-8.2 2.7L14 22l-2.8-7.3L3 12l8.2-2.6L14 2z" fill={p.c} opacity={0.6} />}
          {p.kind === 'heart' && <Path d="M14 24S3 17.7 3 9.7C3 5.8 7.8 3.2 11.1 6.3L14 9l2.9-2.7C20.2 3.2 25 5.8 25 9.7 25 17.7 14 24 14 24z" fill={p.c} opacity={0.55} />}
        </Svg>
      </Animated.View>;
    })}
  </View>;
}
const styles = StyleSheet.create({ particle: { position: 'absolute' } });
