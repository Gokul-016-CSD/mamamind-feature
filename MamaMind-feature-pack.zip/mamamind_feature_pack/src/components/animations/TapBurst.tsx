import React, { useRef } from 'react';
import { Animated, StyleSheet, Text, View } from 'react-native';
import { colors } from '@/theme';

export function TapBurst({ children }: { children: React.ReactNode }) {
  const scale = useRef(new Animated.Value(1)).current;
  const burst = () => {
    scale.setValue(0.98);
    Animated.sequence([
      Animated.timing(scale, { toValue: 1.03, duration: 90, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1, friction: 6, tension: 70, useNativeDriver: true }),
    ]).start();
  };
  return <Animated.View onTouchEnd={burst} style={[styles.wrap, { transform: [{ scale }] }]}>{children}<View pointerEvents="none" style={styles.spark}><Text>✦</Text><Text>♡</Text></View></Animated.View>;
}
const styles = StyleSheet.create({ wrap: { flex: 1 }, spark: { position: 'absolute', right: 14, top: 30, flexDirection: 'row', gap: 4, opacity: .55 },});
