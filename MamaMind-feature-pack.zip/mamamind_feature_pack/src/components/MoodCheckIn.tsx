import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing } from '@/theme';
import { interpretMood, type MoodResult } from '@/services/mood';
import type { Mood } from '@/content/quotes';

const moods: { id: Mood; emoji: string; label: string }[] = [
  { id: 'tired', emoji: '😴', label: 'Tired' }, { id: 'anxious', emoji: '🌧️', label: 'Anxious' },
  { id: 'happy', emoji: '😊', label: 'Happy' }, { id: 'overwhelmed', emoji: '🫠', label: 'A lot' },
  { id: 'lonely', emoji: '🤍', label: 'Lonely' }, { id: 'proud', emoji: '🌷', label: 'Proud' },
];
export function MoodCheckIn() {
  const [result, setResult] = useState<MoodResult | null>(null);
  return <View style={styles.card}><Text style={styles.title}>How are you REALLY feeling?</Text><Text style={styles.sub}>No perfect answer. Just pick what feels closest.</Text><View style={styles.row}>{moods.map(m => <Pressable key={m.id} onPress={() => setResult(interpretMood(m.id))} style={[styles.mood, result?.mood === m.id && styles.selected]}><Text style={styles.emoji}>{m.emoji}</Text><Text style={styles.label}>{m.label}</Text></Pressable>)}</View>{result && <View style={styles.reply}><Text style={styles.replyTitle}>I hear you. ♡</Text><Text style={styles.replyText}>{result.message}</Text><Text style={styles.suggestion}>Tiny next step: {result.suggestion}</Text></View>}</View>;
}
const styles = StyleSheet.create({ card: { backgroundColor: colors.white, borderRadius: radius.lg, padding: spacing.lg }, title: { fontSize: 20, fontWeight: '900', color: colors.text }, sub: { color: colors.muted, marginTop: 4, marginBottom: 14 }, row: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 }, mood: { width: '30%', minWidth: 86, minHeight: 76, borderRadius: radius.md, backgroundColor: colors.background, alignItems: 'center', justifyContent: 'center', padding: 7 }, selected: { backgroundColor: colors.butterYellow }, emoji: { fontSize: 26 }, label: { color: colors.text, fontWeight: '800', fontSize: 12, marginTop: 3 }, reply: { marginTop: 16, backgroundColor: colors.lavenderHug, borderRadius: radius.md, padding: 14 }, replyTitle: { fontWeight: '900', color: colors.text }, replyText: { color: colors.text, marginTop: 4, lineHeight: 20 }, suggestion: { color: colors.text, marginTop: 8, fontWeight: '700' } });
