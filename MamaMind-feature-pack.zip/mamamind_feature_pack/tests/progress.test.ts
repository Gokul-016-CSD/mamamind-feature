import { MILESTONES } from '@/services/progress';
test('journey has the requested seven milestones', () => { expect(MILESTONES).toHaveLength(7); expect(MILESTONES[0].title).toBe('First Cuddle'); expect(MILESTONES[6].title).toBe('Feeling Like Me Again'); });
