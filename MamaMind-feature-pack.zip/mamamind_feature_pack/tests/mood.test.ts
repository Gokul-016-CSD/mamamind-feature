import { interpretMood } from '@/services/mood';
test('mood logic returns an empathetic suggestion', () => { const result = interpretMood('overwhelmed'); expect(result.mood).toBe('overwhelmed'); expect(result.suggestion.length).toBeGreaterThan(5); });
