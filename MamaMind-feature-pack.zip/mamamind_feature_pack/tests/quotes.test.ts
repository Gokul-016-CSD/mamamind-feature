import { quoteForMood } from '@/content/quotes';
test('quote selection returns a non-empty original line', () => { expect(quoteForMood('happy').length).toBeGreaterThan(5); });
